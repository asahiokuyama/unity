﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ball : MonoBehaviour
{
    GameObject cubehp;
    // Start is called before the first frame update
    void Start()
    {
        cubehp = GameObject.Find("Cube");
    }

    // Update is called once per frame
    void Update()
    {
        transform.position += new Vector3(3.0f*Time.deltaTime,0,0);
    }

    private void OnCollisionEnter(Collision other) {
        if(other.gameObject.CompareTag("enemy")){
            cubehp.GetComponent<cube_hp>().hpdown();
            Destroy(this.gameObject);
        }
    }
}
